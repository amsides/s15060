package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {




        //ćwiczenie 1
        System.out.println("ZADANIE 1");
        PolaFigur cw1=new PolaFigur();
        cw1.stratPrgram();
        System.out.println("__________________________________________");


        //ćwiczenie 2
        System.out.println("ZADANIE 2");
        Dzielenie cw2=new Dzielenie();
        cw2.sprawdzLiczbe();
        System.out.println("__________________________________________");

        //ćwiczenie 3
        System.out.println("ZADANIE 3");
        ileCyfr cw3= new ileCyfr();
        cw3.Sprawdzliczbe();
        System.out.println("__________________________________________");

        //ćwiczenie 4
        System.out.println("ZADANIE 4");
        Miesiac cw4=new Miesiac();
        cw4.SpradzMiesiac();
        System.out.println("__________________________________________");

        //ćwiczenie 5
        System.out.println("ZADANIE 5");
        Miesiac2 cw5=new  Miesiac2();
        cw5.SpradzMiesiac();
        System.out.println("__________________________________________");

        //ćwiczenie 6
        System.out.println("ZADANIE 6");
        Signum cw6=new Signum();
        cw6.sprawdźWartośćFunkcjiSignum();
        System.out.println("__________________________________________");

        //ćwiczenie 7
        System.out.println("ZADANIE 7");
        Modulo cw7= new Modulo();
        cw7.sprawdzModulo();
        System.out.println("__________________________________________");







    }






}