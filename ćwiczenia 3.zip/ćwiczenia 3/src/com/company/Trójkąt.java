package com.company;

import java.util.Scanner;

public class Trójkąt {

    int odcinek1,odcinek2,odcinek3;


    void wczytajLiczby() {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Podaj pierwszą liczbę :");
        odcinek1=scanner.nextInt();


        System.out.print("Podaj drugą liczbę :");
        odcinek2=scanner.nextInt();


        System.out.print("Podaj trzecią liczbę :");
        odcinek3=scanner.nextInt();
    }

    void sprawdzTrojkat(){



    }


}
